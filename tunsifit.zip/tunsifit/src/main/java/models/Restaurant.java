package models;

public class Restaurant {
    int id ;
    String nom;
    String  type_de_cuisine;
    String adresse;

    public Restaurant(int id, String nom, String type_de_cuisine, String adresse) {
        this.id = id;
        this.nom = nom;
        this.type_de_cuisine = type_de_cuisine;
        this.adresse = adresse;
    }

    public Restaurant(String nom, String type_de_cuisine, String adresse) {
        this.nom = nom;
        this.type_de_cuisine = type_de_cuisine;
        this.adresse = adresse;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getType_de_cuisine() {
        return type_de_cuisine;
    }

    public void setType_de_cuisine(String type_de_cuisine) {
        this.type_de_cuisine = type_de_cuisine;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

}

